# Sugarbudz

Next.js app ready for Vercel deployment.

## Local Dev
npm install
npm run dev

## Deploy
Push to GitHub and import into Vercel.
